import React from 'react';
import { View, Text, StyleSheet, Switch, Image } from 'react-native';
import { useTheme } from '../../context/ThemeContext';
import BackButton from '../../components/BackButton';

export default function PreferenciasScreen() {
  const { theme, colors, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <BackButton />

      <Image
        source={require('../../../assets/paleta.png')}
        style={styles.image}
        resizeMode="contain"
      />

      <View style={styles.switchContainer}>
        <Text style={[styles.label, { color: colors.text }]}>
          {isDark ? 'Modo Oscuro Activado' : 'Modo Claro Activado'}
        </Text>
        <Switch
          value={isDark}
          onValueChange={toggleTheme}
          thumbColor={isDark ? '#4a90e2' : '#007bff'}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 60,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  image: {
    width: 150,
    height: 150,
    marginBottom: 30,
  },
  switchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
  label: {
    fontSize: 18,
  },
});
