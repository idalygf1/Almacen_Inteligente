import React from 'react';
import { View, Text } from 'react-native';

const InventarioListaCompras = () => {
  return (
    <View>
      <Text>Pantalla Lista de Compras</Text>
    </View>
  );
};

export default InventarioListaCompras;
