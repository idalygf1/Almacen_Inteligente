export default function FinanzasAnalisis() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Pantalla: Finanzas - Análisis</Text>
    </View>
  );
}
