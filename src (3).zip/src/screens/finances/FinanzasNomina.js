export default function FinanzasNomina() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Pantalla: Finanzas - Nómina</Text>
    </View>
  );
}
