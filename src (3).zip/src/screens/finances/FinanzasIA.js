export default function FinanzasIA() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Pantalla: Finanzas - IA</Text>
    </View>
  );
}
