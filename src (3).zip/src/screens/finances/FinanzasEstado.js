export default function FinanzasEstado() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Pantalla: Finanzas - Estado</Text>
    </View>
  );
}
