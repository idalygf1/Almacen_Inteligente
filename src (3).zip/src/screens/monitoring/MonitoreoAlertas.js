import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  Modal,
} from 'react-native';
import axios from 'axios';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { useAuth } from '../../context/AuthContext';
import { Picker } from '@react-native-picker/picker';
import { useTheme } from '../../context/ThemeContext';
import { LinearGradient } from 'expo-linear-gradient';
import gasImg from './../../../assets/gas.png';
import humedadImg from './../../../assets/humedad.png';
import temperaturaImg from './../../../assets/temperatura.png';
import vibracionImg from './../../../assets/vibracion.png';
import { Image } from 'react-native';



const MonitoreoAlertas = () => {
  const { token } = useAuth();
  const { colors } = useTheme();
  const [alerts, setAlerts] = useState([]);
  const [filteredAlerts, setFilteredAlerts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [sensorModalVisible, setSensorModalVisible] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [filterSensor, setFilterSensor] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const fetchAlerts = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        'https://monitoring.nexusutd.online/monitoring/notifications?limit=1000',
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const allAlerts = response.data.notifications || [];
      setAlerts(allAlerts);
      setFilteredAlerts(allAlerts);
    } catch (error) {
      console.error('Error al obtener alertas:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
  }, []);

  useEffect(() => {
    let filtered = [...alerts];
    if (filterSensor !== 'all') {
      filtered = filtered.filter(alert =>
        alert.sensor?.toLowerCase() === filterSensor.toLowerCase()
      );
    }
    if (filterStatus !== 'all') {
      filtered = filtered.filter(alert =>
        alert.status?.toLowerCase() === filterStatus.toLowerCase()
      );
    }
    setFilteredAlerts(filtered);
  }, [filterSensor, filterStatus, alerts]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return format(date, "hh:mm a '–' d 'de' MMMM", { locale: es });
  };

  const getSensorStatus = () => [
  { name: 'Temperatura', image: temperaturaImg },
  { name: 'Humedad', image: humedadImg },
  { name: 'Gas', image: gasImg },
  { name: 'Vibración', image: vibracionImg },
];


  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>A L E R T A S</Text>
        <TouchableOpacity onPress={() => setSensorModalVisible(true)} style={styles.sensorButton}>
          <Text style={styles.sensorEmoji}>📡</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.filters}>
        <Picker
          selectedValue={filterSensor}
          onValueChange={setFilterSensor}
          style={styles.picker}
        >
          <Picker.Item label="Sensor: Todos" value="all" />
          <Picker.Item label="Gas" value="Gas" />
          <Picker.Item label="Vibración" value="Vibration" />
        </Picker>

        <Picker
          selectedValue={filterStatus}
          onValueChange={setFilterStatus}
          style={styles.picker}
        >
          <Picker.Item label="Estado: Todos" value="all" />
          <Picker.Item label="Leído" value="read" />
          <Picker.Item label="No leído" value="unread" />
        </Picker>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={colors.primary} />
      ) : (
        filteredAlerts.map((alert, index) => (
          <LinearGradient key={index} colors={colors.gradientCard} style={styles.card}>
            <TouchableOpacity onPress={() => { setSelectedAlert(alert); setModalVisible(true); }}>
              <Text style={styles.cardTitle}>
                {alert.sensor} – {formatDate(alert.timestamp)}
              </Text>
              <Text style={styles.cardMessage}>{alert.message}</Text>
            </TouchableOpacity>
          </LinearGradient>
        ))
      )}

      <Modal
  visible={sensorModalVisible}
  animationType="fade"
  transparent={true}
  onRequestClose={() => setSensorModalVisible(false)}
>
  <View style={styles.modalBackground}>
    <View style={styles.sensorModalContainer}>
      <Text style={styles.modalTitle}>Estado de Sensores</Text>
      {getSensorStatus().map((sensor, index) => (
        <View key={index} style={styles.sensorRow}>
          <Image source={sensor.image} style={styles.sensorImage} />
          <Text style={styles.sensorName}>{sensor.name}</Text>
          <Text style={styles.sensorStatus}>⚠️ Offline</Text>
        </View>
      ))}
      <TouchableOpacity onPress={() => setSensorModalVisible(false)}>
        <Text style={styles.closeModal}>Cerrar</Text>
      </TouchableOpacity>
    </View>
  </View>
</Modal>

    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16, paddingBottom: 100 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 22, fontWeight: 'bold' },
  sensorButton: {
    backgroundColor: '#2563EB',
    padding: 10,
    borderRadius: 50,
  },
  sensorEmoji: { fontSize: 22 },
  filters: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  picker: { flex: 1, backgroundColor: '#fff', borderRadius: 20, height: 53 },
  card: {
    padding: 18,
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    elevation: 4,
  },
  cardTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 6 },
  cardMessage: { fontSize: 15 },
  modalBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalCard: {
    width: '85%',
    padding: 24,
    borderRadius: 18,
    alignItems: 'center',
    elevation: 6,
  },
  modalSensor: { fontSize: 20, fontWeight: 'bold', marginBottom: 4 },
  modalDate: { fontSize: 14, marginBottom: 10 },
  modalMessage: { fontSize: 16, textAlign: 'center', marginBottom: 16 },
  closeModal: { fontSize: 16, fontWeight: 'bold' },
  sensorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    justifyContent: 'space-between',
    width: '100%',
  },
  sensorName: { fontSize: 16 },
  sensorStatus: { fontSize: 14, fontWeight: 'bold', color: '#facc15' },
  sensorModalContainer: {
  backgroundColor: '#fff',
  padding: 26,
  borderRadius: 14,
  width: '85%',
  alignItems: 'center',
  shadowColor: '#000',
  elevation: 5,
},
sensorRow: {
  flexDirection: 'row',
  alignItems: 'center',
  marginVertical: 10,
  width: '100%',
  justifyContent: 'space-between',
},
sensorImage: {
  width: 28,
  height: 28,
  resizeMode: 'contain',
},
sensorName: {
  flex: 1,
  fontSize: 16,
  fontWeight: '600',
  color: '#0f172a',
  marginLeft: 12,
},
sensorStatus: {
  fontSize: 14,
  fontWeight: 'bold',
  color: '#facc15',
},
modalTitle: {
  fontSize: 20,
  fontWeight: 'bold',
  color: '#1e293b', // gris azulado oscuro (se adapta bien a dark y light)
  marginBottom: 16,
  textAlign: 'center',
  textTransform: 'uppercase',
  letterSpacing: 1.2,
},

});

export default MonitoreoAlertas;
