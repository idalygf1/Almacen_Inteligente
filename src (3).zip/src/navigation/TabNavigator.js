// src/navigation/TabNavigator.js
import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeScreen from '../screens/HomeScreen';
import PerfilScreen from '../screens/PerfilScreen';
import FinanzasStack from './FinanzasStack';
import InventarioStack from './InventarioStack';
import MonitoreoStack from './MonitoreoStack';

const Tab = createBottomTabNavigator();

const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ color, size }) => {
          let iconName;
          switch (route.name) {
            case 'Inicio':
              iconName = 'home-outline';
              break;
            case 'Finanzas':
              iconName = 'card-outline';
              break;
            case 'Inventario':
              iconName = 'cube-outline';
              break;
            case 'Monitoreo':
              iconName = 'analytics-outline';
              break;
            case 'Perfil':
              iconName = 'person-outline';
              break;
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#2c80ff',
        tabBarInactiveTintColor: 'gray',
      })}
    >
      <Tab.Screen name="Inicio" component={HomeScreen} />
      <Tab.Screen name="Finanzas" component={FinanzasStack} />
      <Tab.Screen name="Inventario" component={InventarioStack} />
      <Tab.Screen name="Monitoreo" component={MonitoreoStack} />
      <Tab.Screen name="Perfil" component={PerfilScreen} />
    </Tab.Navigator>
  );
};

export default TabNavigator;
