export const INVENTORY_URL = 'https://inventory.nexusutd.online';
